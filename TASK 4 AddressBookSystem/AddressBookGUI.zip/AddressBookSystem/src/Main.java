import javafx.application.Application;
import javafx.beans.property.*;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.*;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import java.io.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class Main extends Application {

    private List<Contact> contacts = new ArrayList<>();
    private TableView<Contact> table = new TableView<>();
    private TextField searchField = new TextField();
    private Button searchButton = new Button("Search");

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Address Book");

        // Apply basic styling to buttons
        String buttonStyle = "-fx-font-size: 14px; -fx-padding: 8px 16px;";
        String searchButtonStyle = "-fx-font-size: 14px; -fx-padding: 8px 16px; -fx-background-color: #4CAF50; -fx-text-fill: white;";

        // Create UI elements
        Button addButton = new Button("Add Contact");
        addButton.setStyle(buttonStyle);
        Button removeButton = new Button("Remove Contact");
        removeButton.setStyle(buttonStyle);
        Button updateButton = new Button("Update Contact");
        updateButton.setStyle(buttonStyle);
        TextField nameInput = new TextField();
        TextField phoneNumberInput = new TextField();
        TextField emailInput = new TextField();
        TextField addressInput = new TextField(); // New field for address
        DatePicker birthdayPicker = new DatePicker(); // New field for birthday
        TextField notesInput = new TextField(); // New field for notes

        // Apply styling to the search button
        searchButton.setStyle(searchButtonStyle);

        // Create sorting buttons
        Button sortByNameButton = new Button("Sort by Name");
        sortByNameButton.setStyle(buttonStyle);
        Button sortByPhoneNumberButton = new Button("Sort by Phone Number");
        sortByPhoneNumberButton.setStyle(buttonStyle);
        Button sortByEmailButton = new Button("Sort by Email");
        sortByEmailButton.setStyle(buttonStyle);

        // Create export and import buttons
        Button exportButton = new Button("Export to CSV");
        exportButton.setStyle(buttonStyle);
        Button importButton = new Button("Import from CSV");
        importButton.setStyle(buttonStyle);

        // Table columns
        TableColumn<Contact, String> nameColumn = new TableColumn<>("Name");
        nameColumn.setCellValueFactory(cellData -> cellData.getValue().nameProperty());

        TableColumn<Contact, String> phoneNumberColumn = new TableColumn<>("Phone Number");
        phoneNumberColumn.setCellValueFactory(cellData -> cellData.getValue().phoneNumberProperty());

        TableColumn<Contact, String> emailColumn = new TableColumn<>("Email");
        emailColumn.setCellValueFactory(cellData -> cellData.getValue().emailProperty());

        TableColumn<Contact, String> addressColumn = new TableColumn<>("Address"); // New column for address
        addressColumn.setCellValueFactory(cellData -> cellData.getValue().addressProperty());

        TableColumn<Contact, LocalDate> birthdayColumn = new TableColumn<>("Birthday"); // New column for birthday
        birthdayColumn.setCellValueFactory(cellData -> cellData.getValue().birthdayProperty());

        TableColumn<Contact, String> notesColumn = new TableColumn<>("Notes"); // New column for notes
        notesColumn.setCellValueFactory(cellData -> cellData.getValue().notesProperty());

        table.getColumns().addAll(nameColumn, phoneNumberColumn, emailColumn, addressColumn, birthdayColumn, notesColumn);

        // Add event handlers
        addButton.setOnAction(event -> {
            Contact contact = new Contact(
                    nameInput.getText(),
                    phoneNumberInput.getText(),
                    emailInput.getText(),
                    addressInput.getText(), // New field for address
                    birthdayPicker.getValue(), // New field for birthday
                    notesInput.getText() // New field for notes
            );
            contacts.add(contact);
            table.getItems().add(contact);
            TextField[] textFields = { nameInput, phoneNumberInput, emailInput, addressInput, notesInput };
           clearInputFields(textFields);

            // Show a confirmation message
            showConfirmation("Contact added successfully.");
        });

        removeButton.setOnAction(event -> {
            Contact selectedContact = table.getSelectionModel().getSelectedItem();
            if (selectedContact != null) {
                contacts.remove(selectedContact);
                table.getItems().remove(selectedContact);

                // Show a confirmation message
                showConfirmation("Contact removed successfully.");
            }
        });

        updateButton.setOnAction(event -> {
            Contact selectedContact = table.getSelectionModel().getSelectedItem();
            if (selectedContact != null) {
                selectedContact.setName(nameInput.getText());
                selectedContact.setPhoneNumber(phoneNumberInput.getText());
                selectedContact.setEmail(emailInput.getText());
                selectedContact.setAddress(addressInput.getText()); // New field for address
                selectedContact.setBirthday(birthdayPicker.getValue()); // New field for birthday
                selectedContact.setNotes(notesInput.getText()); // New field for notes
                table.refresh();
                TextField[] textFields1 = { nameInput, phoneNumberInput, emailInput, addressInput, notesInput };
                clearInputFields(textFields1);

                // Show a confirmation message
                showConfirmation("Contact updated successfully.");
            }
        });

        // Add sorting event handlers
        sortByNameButton.setOnAction(event -> {
            table.getItems().sort(Comparator.comparing(Contact::getName));
        });

        sortByPhoneNumberButton.setOnAction(event -> {
            table.getItems().sort(Comparator.comparing(Contact::getPhoneNumber));
        });

        sortByEmailButton.setOnAction(event -> {
            table.getItems().sort(Comparator.comparing(Contact::getEmail));
        });

        // Add search functionality
        searchButton.setOnAction(event -> {
            String query = searchField.getText().toLowerCase();
            List<Contact> filteredContacts = contacts.stream()
                    .filter(contact ->
                            contact.getName().toLowerCase().contains(query) ||
                                    contact.getPhoneNumber().toLowerCase().contains(query) ||
                                    contact.getEmail().toLowerCase().contains(query) ||
                                    contact.getAddress().toLowerCase().contains(query) || // New field for address
                                    (contact.getBirthday() != null && contact.getBirthday().toString().contains(query)) || // New field for birthday
                                    contact.getNotes().toLowerCase().contains(query) // New field for notes
                    )
                    .collect(Collectors.toList());

            // Clear and update the table with filtered contacts
            table.getItems().clear();
            table.getItems().addAll(filteredContacts);
        });

        // Add export functionality
        exportButton.setOnAction(event -> {
            FileChooser fileChooser = new FileChooser();
            fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("CSV Files (*.csv)", "*.csv"));
            File file = fileChooser.showSaveDialog(primaryStage);
            if (file != null) {
                exportContactsToCsv(file);
            }
        });

        // Add import functionality
        importButton.setOnAction(event -> {
            FileChooser fileChooser = new FileChooser();
            fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("CSV Files (*.csv)", "*.csv"));
            File file = fileChooser.showOpenDialog(primaryStage);
            if (file != null) {
                importContactsFromCsv(file);
            }
        });
        // Create labels for input fields
        Label nameLabel = new Label("Name:");
        Label phoneNumberLabel = new Label("Phone Number:");
        Label emailLabel = new Label("Email:");
        Label addressLabel = new Label("Address:");
        Label birthdayLabel = new Label("Birthday:");
        Label notesLabel = new Label("Notes:");

// ... existing code ...
        table.setPrefHeight(600);
// Create layout
        HBox searchBox = new HBox(searchField, searchButton);
        HBox exportImportBox = new HBox(exportButton, importButton);
        VBox layout = new VBox(10);
        layout.setPadding(new Insets(10));
        layout.setStyle("-fx-background-color: #f0f0f0;"); // Set a light gray background
        layout.getChildren().addAll(
                nameLabel, nameInput,
                phoneNumberLabel, phoneNumberInput,
                emailLabel, emailInput,
                addressLabel, addressInput,
                birthdayLabel, birthdayPicker,
                notesLabel, notesInput,
                addButton, removeButton, updateButton,    sortByNameButton, sortByPhoneNumberButton, sortByEmailButton,
                searchBox, // Add the search box
                exportImportBox, // Add the export and import buttons
                table
        );


        ScrollPane scrollPane = new ScrollPane(layout);
        scrollPane.setFitToWidth(true);
        scrollPane.setFitToHeight(true);

        Scene scene = new Scene(scrollPane, 800, 600);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private void clearInputFields(TextField... fields) {
        for (TextField field : fields) {
            field.clear();
        }
    }

    private void showConfirmation(String message) {
        Alert confirmation = new Alert(AlertType.INFORMATION);
        confirmation.setTitle("Confirmation");
        confirmation.setHeaderText(null);
        confirmation.setContentText(message);
        confirmation.showAndWait();
    }

    private void showError(String message) {
        Alert error = new Alert(AlertType.ERROR);
        error.setTitle("Error");
        error.setHeaderText(null);
        error.setContentText(message);
        error.showAndWait();
    }

    private void exportContactsToCsv(File file) {
        try (PrintWriter writer = new PrintWriter(file)) {
            for (Contact contact : contacts) {
                writer.println(
                        contact.getName() + "," +
                                contact.getPhoneNumber() + "," +
                                contact.getEmail() + "," +
                                contact.getAddress() + "," +
                                (contact.getBirthday() == null ? "" : contact.getBirthday()) + "," +
                                contact.getNotes());
            }
            showConfirmation("Contacts exported to CSV successfully.");
        } catch (IOException e) {
            showError("Error exporting contacts to CSV file.");
        }
    }

    private void importContactsFromCsv(File file) {
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length >= 6) {
                    Contact contact = new Contact(
                            parts[0],
                            parts[1],
                            parts[2],
                            parts[3],
                            parts[4].isEmpty() ? null : LocalDate.parse(parts[4]),
                            parts[5]
                    );
                    contacts.add(contact);
                }
            }
            table.getItems().clear();
            table.getItems().addAll(contacts);
            showConfirmation("Contacts imported from CSV successfully.");
        } catch (IOException e) {
            showError("Error importing contacts from CSV file.");
        }
    }

    public class Contact {
        private StringProperty name;
        private StringProperty phoneNumber;
        private StringProperty email;
        private StringProperty address; // New field for address
        private ObjectProperty<LocalDate> birthday; // New field for birthday
        private StringProperty notes; // New field for notes

        public Contact(String name, String phoneNumber, String email, String address, LocalDate birthday, String notes) {
            this.name = new SimpleStringProperty(name);
            this.phoneNumber = new SimpleStringProperty(phoneNumber);
            this.email = new SimpleStringProperty(email);
            this.address = new SimpleStringProperty(address);
            this.birthday = new SimpleObjectProperty<>(birthday);
            this.notes = new SimpleStringProperty(notes);
        }

        // Getter and setter methods for all fields

        public String getName() {
            return name.get();
        }

        public void setName(String name) {
            this.name.set(name);
        }

        public StringProperty nameProperty() {
            return name;
        }

        public String getPhoneNumber() {
            return phoneNumber.get();
        }

        public void setPhoneNumber(String phoneNumber) {
            this.phoneNumber.set(phoneNumber);
        }

        public StringProperty phoneNumberProperty() {
            return phoneNumber;
        }

        public String getEmail() {
            return email.get();
        }

        public void setEmail(String email) {
            this.email.set(email);
        }

        public StringProperty emailProperty() {
            return email;
        }

        public String getAddress() {
            return address.get();
        }

        public void setAddress(String address) {
            this.address.set(address);
        }

        public StringProperty addressProperty() {
            return address;
        }

        public LocalDate getBirthday() {
            return birthday.get();
        }

        public void setBirthday(LocalDate birthday) {
            this.birthday.set(birthday);
        }

        public ObjectProperty<LocalDate> birthdayProperty() {
            return birthday;
        }

        public String getNotes() {
            return notes.get();
        }

        public void setNotes(String notes) {
            this.notes.set(notes);
        }

        public StringProperty notesProperty() {
            return notes;
        }
    }
}